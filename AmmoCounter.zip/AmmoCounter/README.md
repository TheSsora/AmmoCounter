# AmmoCounter

A lightweight addon for World of Warcraft: Forever that displays the total number of arrows and bullets in your bags.

## Features

- Counts projectile items across your bags.
- Updates when your bags change.
- Supports Russian and English client locales.
- Movable display: drag it with the left mouse button.
- Toggle the display with `/ammocounter`.

## Installation

1. Download or clone this repository.
2. Put the `AmmoCounter` folder into `World of Warcraft/_forever_/Interface/AddOns/`.
3. Restart the game or reload the UI with `/reload`.

The folder should contain:

```
AmmoCounter/
├── AmmoCounter.toc
└── AmmoCounter.lua
```

## Compatibility

The addon targets the WoW Forever interface version `16001` and uses the modern container and item APIs. It identifies projectile items by item class ID.

Please report any errors or compatibility issues through GitHub Issues.
