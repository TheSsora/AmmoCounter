local L = {}
local locale = GetLocale()

if locale == "ruRU" then
    L.AMMO = "Снаряды: "
else
    L.AMMO = "Ammo: "
end

local frame = CreateFrame("Frame", "AmmoCounterFrame", UIParent, "BackdropTemplate")
frame:SetSize(150, 28)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, -120)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

frame:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true,
    tileSize = 16,
    edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
})
frame:SetBackdropColor(0, 0, 0, 0.75)

local text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
text:SetPoint("CENTER")
text:SetText(L.AMMO .. "0")

local function IsProjectile(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfoInstant then
        return false
    end

    local _, _, _, _, _, classID = C_Item.GetItemInfoInstant(itemID)
    return classID == 6
end

local function UpdateAmmoCount()
    local total = 0

    for bag = 0, NUM_BAG_SLOTS do
        local slots = C_Container.GetContainerNumSlots(bag)

        for slot = 1, slots do
            local itemInfo = C_Container.GetContainerItemInfo(bag, slot)

            if itemInfo and itemInfo.itemID and IsProjectile(itemInfo.itemID) then
                total = total + (itemInfo.stackCount or 1)
            end
        end
    end

    text:SetText(L.AMMO .. total)
end

frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("BAG_UPDATE_DELAYED")
frame:SetScript("OnEvent", UpdateAmmoCount)

SLASH_AMMOCOUNTER1 = "/ammocounter"
SlashCmdList.AMMOCOUNTER = function()
    if frame:IsShown() then
        frame:Hide()
    else
        frame:Show()
        UpdateAmmoCount()
    end
end
