local ADDON_NAME = "AmmoCounter"

local L = {}
if GetLocale() == "ruRU" then
    L.AMMO = "Снаряды: "
    L.FILL = "Пополнить"
    L.NO_BAG = "Экипируй колчан или подсумок."
    L.NO_AMMO = "Торговец не продаёт подходящие снаряды."
    L.FILLED = "AmmoCounter: покупка завершена."
    L.COST = "Стоимость пополнения: "
    L.CLICK = "Нажми для покупки боеприпасов на пустые ячейки."
else
    L.AMMO = "Ammo: "
    L.FILL = "Refill"
    L.NO_BAG = "Equip a quiver or ammo pouch first."
    L.NO_AMMO = "This vendor has no matching ammunition."
    L.FILLED = "AmmoCounter: refill finished."
    L.COST = "Refill cost: "
    L.CLICK = "Click to buy ammo for empty slots."
end

-- Counter display
local frame = CreateFrame("Frame", "AmmoCounterFrame", UIParent, "BackdropTemplate")
frame:SetSize(150, 28)
frame:SetPoint("CENTER", UIParent, "CENTER", 0, -120)
frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetScript("OnDragStart", frame.StartMoving)
frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
frame:SetBackdrop({
    bgFile = "Interface/Tooltips/UI-Tooltip-Background",
    edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
    tile = true, tileSize = 16, edgeSize = 12,
    insets = { left = 3, right = 3, top = 3, bottom = 3 },
})
frame:SetBackdropColor(0, 0, 0, 0.75)
local text = frame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
text:SetPoint("CENTER")
text:SetText(L.AMMO .. "0")

local function ProjectileKind(itemID)
    if not itemID or not C_Item or not C_Item.GetItemInfoInstant then return nil end
    local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
    if classID ~= 6 then return nil end -- projectile
    if subclassID == 2 then return "arrow" end
    if subclassID == 3 then return "bullet" end
end

local function UpdateAmmoCount()
    local total = 0
    for bag = 0, NUM_BAG_SLOTS do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and ProjectileKind(info.itemID) then
                total = total + (info.stackCount or 1)
            end
        end
    end
    text:SetText(L.AMMO .. total)
end

-- Locate an equipped quiver/ammo pouch (equipped bag slots 1..NUM_BAG_SLOTS).
local function FindAmmoBag()
    for bag = 1, NUM_BAG_SLOTS do
        local invSlot = C_Container.ContainerIDToInventoryID(bag)
        local itemID = invSlot and GetInventoryItemID("player", invSlot)
        if itemID then
            local _, _, _, _, _, classID, subclassID = C_Item.GetItemInfoInstant(itemID)
            if classID == 11 then -- quiver/ammo pouch item class
                if subclassID ==  quiverSubclass then return bag, "arrow" end
                if subclassID == ammoPouchSubclass then return bag, "bullet" end
            end
        end
    end
end

local quiverSubclass, ammoPouchSubclass
if Enum and Enum.ItemQuiverSubclass then
    quiverSubclass = Enum.ItemQuiverSubclass.Quiver
    ammoPouchSubclass = Enum.ItemQuiverSubclass.Ammopouch
end

local function FindVendorAmmo(kind)
    for index = 1, GetMerchantNumItems() do
        local itemID = GetMerchantItemID(index)
        if itemID and ProjectileKind(itemID) == kind then
            local info = C_MerchantFrame.GetItemInfo(index)
            if info and info.price and info.price > 0 and info.isPurchasable then
                local stack = info.stackCount or 1
                local maxStack = GetMerchantItemMaxStack(index) or stack
                if maxStack > 0 then
                    return index, itemID, info.name, info.price, maxStack
                end
            end
        end
    end
end

local function Refill()
    if not MerchantFrame or not MerchantFrame:IsShown() then return end
    local bag, kind = FindAmmoBag()
    if not bag then print("|cffffd200AmmoCounter:|r " .. L.NO_BAG); return end

    local index, itemID, name, price, vendorStack = FindVendorAmmo(kind)
    if not index then print("|cffffd200AmmoCounter:|r " .. L.NO_AMMO); return end

    local freeSlots = C_Container.GetContainerNumFreeSlots(bag)
    local slots = C_Container.GetContainerNumSlots(bag)
    local used = slots - (freeSlots or 0)
    -- Buy one vendor stack for every currently empty slot. Existing partial
    -- stacks are deliberately left untouched.
    local stacksToBuy = math.max(0, freeSlots or 0)
    if stacksToBuy == 0 then
        print("|cffffd200AmmoCounter:|r " .. (GetLocale()=="ruRU" and "Колчан уже заполнен." or "The ammo bag is full."))
        return
    end
    local totalCost = stacksToBuy * price
    if GetMoney() < totalCost then
        print("|cffffd200AmmoCounter:|r " .. (GetLocale()=="ruRU" and "Недостаточно золота." or "Not enough gold."))
        return
    end

    -- WoW's vendor API buys in stack quantities; cap each call to its max.
    local remaining = stacksToBuy
    while remaining > 0 do
        local batch = math.min(remaining, vendorStack)
        BuyMerchantItem(index, batch)
        remaining = remaining - batch
    end
    print(("|cffffd200AmmoCounter:|r %s — %d %s."):format(
        GetLocale()=="ruRU" and "куплено" or "Bought", stacksToBuy * vendorStack, name or "ammo"))
    UpdateAmmoCount()
end

-- Button on merchant frame; action is manual to prevent unexpected spending.
local vendorButton = CreateFrame("Button", "AmmoCounterRefillButton", MerchantFrame, "UIPanelButtonTemplate")
vendorButton:SetSize(100, 22)
vendorButton:SetPoint("TOPLEFT", MerchantFrame, "TOPLEFT", 12, -30)
vendorButton:SetText(L.FILL)
vendorButton:SetScript("OnClick", Refill)
vendorButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(L.CLICK)
    GameTooltip:Show()
end)
vendorButton:SetScript("OnLeave", GameTooltip_Hide)
vendorButton:Hide()

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("BAG_UPDATE_DELAYED")
events:RegisterEvent("MERCHANT_SHOW")
events:RegisterEvent("MERCHANT_CLOSED")
events:SetScript("OnEvent", function(_, event)
    if event == "PLAYER_ENTERING_WORLD" or event == "BAG_UPDATE_DELAYED" then
        UpdateAmmoCount()
    elseif event == "MERCHANT_SHOW" then
        vendorButton:Show()
    elseif event == "MERCHANT_CLOSED" then
        vendorButton:Hide()
    end
end)

SLASH_AMMOCOUNTER1 = "/ammocounter"
SlashCmdList.AMMOCOUNTER = function()
    if frame:IsShown() then frame:Hide() else frame:Show(); UpdateAmmoCount() end
end
