# AmmoCounter

A lightweight WoW Forever addon that counts arrows and bullets and offers a manual vendor refill button.

## Features
- Counts projectiles in bags.
- Russian/English label.
- Movable counter; `/ammocounter` toggles it.
- **Refill** button in the vendor window buys vendor ammo for the currently empty slots of an equipped quiver/ammo pouch.
- Manual purchase only: no automatic spending when opening a vendor.

## Install
Copy the `AmmoCounter` folder to `World of Warcraft/_forever_/Interface/AddOns/` and `/reload`.
